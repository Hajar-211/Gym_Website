<!DOCTYPE HTML>
<html>
<head>
  <link rel="stylesheet" href="css\styleConact.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<title> GYM TIME </title>
<style>
body {
  background-image: url('img/img7.jfif');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}

</style>
</head>
<body>

<nav >
    <ul class="menu">
      <Center><a href="PageHome.html">HOME</a> ||
        <a href="FeaturesPge.html">FEATURES</a> ||
        <a href="Area.html">GYM AREA</a> ||
        <a href="OpinionPage.html">CLINETS OPINION</a> ||
        <a href="ConcatPage.php">MEET US</a> ||
        <a href="Registerlogin\login.php">JOIN NOW</a></Center>
    </ul>
</nav>
<div class="title-text">
        <h1>Visit Club Today</h1>
        <img src="img/gym1.png" alt="" class="contact-img">
    </div>

    <div class="contact-row">
        <div class="left-contact">
            <h3>Open Hours</h3>
            <p><i class="fa fa-clock-o"></i>Sunday to Thursday - 7:00am TO 10:00pm </p>
            <p><i class="fa fa-clock-o"></i>Friday & Satuerday - 2:00pm To 10:00 pm</p>
        </div>
        <div class="right-contact">
            <h3>Get in Touch</h3>
            <p><i class="fa fa-map-marker"></i>Abha  King Abdul King Abdulaziz Road </p>
            <p><i class="fa fa-paper-plane"></i> OxygenGym@gamil.com</p>
            <p><i class="fa fa-phone"></i> Telephone:0055443366 </p>
        </div>
    </div>

   <div id="problem">
       <div class="form">
         <p>For any suggestions or inquiries,<br>
            Please send an email to<br>
           OxygenGym@gamil.com</p>
     <form name="test" action="" method="post">
     <label for="name"> Name:</label><br>
    <input type="text" name="name" placeholder="name" required />
    <label for="email"> Email:</label><br>
    <input type="email" name="email" placeholder="email" required />
    <label for="desciption">The Message: </label><br>
    <input type="textarea" name="desciption" placeholder="desciption" required />
    <input type="submit" name="submit" value="submit" />
    </form>
  </div></div>
  <?php
  require('db1.php');
  // If form submitted, insert values into the database.
  if (isset($_REQUEST['name'])){
  	$name = stripslashes($_REQUEST['name']);
  	$name = mysqli_real_escape_string($con,$name);
  	$email = stripslashes($_REQUEST['email']);
  	$email = mysqli_real_escape_string($con,$email);
  	$desciption = stripslashes($_REQUEST['desciption']);
    $desciption = mysqli_real_escape_string($con,$desciption);
  	$trn_date = date("Y-m-d H:i:s");
          $query = "INSERT into `users` (name, desciption, email, trn_date)
  VALUES ('$name', '$desciption', '$email', '$trn_date')";
          $result = mysqli_query($con,$query);
          if($result){
              echo "<div class='form'>
  <h3>You are request has been received successfully.</h3>
  <h4>We have received your query and stored your information thank you for contacting us, we will get back to you shortly.</h4></div>";
          }
      }else{
  ?>
    <?php } ?>
  </body>
  </html>
